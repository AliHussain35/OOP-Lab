Q1:

![](./image1.png){width="2.340398075240595in"
height="1.3195122484689414in"}

Q2:

![](./image2.png){width="4.4030041557305335in"
height="1.1111679790026248in"}

Q3:

![](./image3.png){width="4.36133530183727in"
height="2.0001027996500436in"}

Q4:

//used this pointer in code

![](./image4.png){width="5.194711286089239in"
height="2.069550524934383in"}

Q5:

![](./image5.png){width="4.36133530183727in"
height="2.215391513560805in"}
